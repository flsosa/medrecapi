# medrecapi

sample springboot application to build with wercker, deploy to Kubernetes

Welcome
