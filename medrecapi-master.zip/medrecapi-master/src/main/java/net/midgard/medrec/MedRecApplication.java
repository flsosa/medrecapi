package net.midgard.medrec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedRecApplication {

	public static void main(String[] args) {
		SpringApplication.run(MedRecApplication.class, args);
	}
}
